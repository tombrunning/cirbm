#ifndef MEM_INIT_H_
#define MEM_INIT_H_

bool mem_init(alt_u32 BaseAddr, alt_u32 ByteLen, alt_u32 InitValue);


#endif /*MEM_INIT_H_*/
