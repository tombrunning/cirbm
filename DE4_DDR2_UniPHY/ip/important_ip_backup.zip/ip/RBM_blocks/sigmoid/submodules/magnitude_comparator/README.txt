Notice: 
    the main verilog file  could be different from the module file integrated in the system. Be careful when you change one and sync the other.