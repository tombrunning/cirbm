#ifndef MEM_TEST_H_
#define MEM_TEST_H_

bool TMEM_Verify(alt_u32 BaseAddr, alt_u32 ByteLen, alt_u32 InitValue);


#endif /*MEM_TEST_H_*/
