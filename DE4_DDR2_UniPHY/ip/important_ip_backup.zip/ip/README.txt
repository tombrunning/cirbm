rbm_demo.v      -- wrapper
Master_Template -- ppl memory reader